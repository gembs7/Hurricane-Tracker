test_that( "Storm Size returns properly", {
  s <- storm_size(hurdata[44703,])
  expect_equal(s, TRUE)

}

)
