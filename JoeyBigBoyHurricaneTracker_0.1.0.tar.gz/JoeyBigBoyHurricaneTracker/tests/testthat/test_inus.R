test_that("Test that InUS correctly identifies if the storm reached landfall in
          the Continental US", {
US<- InUS("AL132019")
expect_equal(US, "No")

}

)


