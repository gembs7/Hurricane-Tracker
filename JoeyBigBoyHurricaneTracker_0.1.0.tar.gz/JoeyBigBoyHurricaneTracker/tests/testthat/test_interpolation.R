test_that("Test if Interpolation function accurately determines the
          latitude and longitude values determined through interpolation", {
  inter<- Interpolate("AL112017")[2,1]
  expect_equal(inter, 16.1033333  )

  }
)


