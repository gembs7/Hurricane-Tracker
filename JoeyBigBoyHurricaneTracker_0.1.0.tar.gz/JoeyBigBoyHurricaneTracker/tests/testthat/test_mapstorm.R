test_that( "Map Storm returns correct number of storm id plots", {
  maps <- map_storm(c("AL012020", "AL022020", "AL032020"))
  expect_equal(maps, 3)

}

)

test_that( "Map Storm returns correct number of storm id plots 2", {
    maps <- map_storm(c("AL012020"))
    expect_equal(maps, 1)


  }

    )
