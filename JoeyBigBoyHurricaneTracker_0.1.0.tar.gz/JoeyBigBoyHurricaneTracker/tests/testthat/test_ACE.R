test_that( "ACE returns correct output", {
  ace <- ACE("AL012020")
  expect_equal(ace, list("ACE" = 35075, "ACE_reduced" = 3.5075))

}

)
