#' Given a vector of Hurricane IDS, will map the path of the storm
#' with given ID over its duration.
#'
#' @param ids a vector of storm IDs from the hurricane dataset
#' @param title title of the map being created
#' @return a color coded map of the storm tracks
#' @export
map_storm = function(ids, title = "storm map") {
  colors = rep(c("red", "blue", "green", "yellow", "purple", "pink", "cyan",
                 "orange", "black", "dark green", "navy", "tomato1", "wheat4",
                 "brown", "slateblue2", "salmon1",
                 "peachpuff2", "plum", "olivedrab", "maroon3", "lightskyblue",
                 "coral", "lawngreen", "honeydew", "grey17", "cornsilk"), 10)
  ci =1

  maps::map("world", fill = TRUE, col = "light gray", bg = "white", xlim = c(-180, 50))
  maps::map("state", fill = FALSE, add = TRUE, col = "black", lwd = 0.3)

  for (id in ids){
    graphics::points(hurdata$Longitude[grep(id, hurdata$ID)], hurdata$Latitude[grep(id, hurdata$ID)], pch = 16, col = colors[ci], cex = .73)
    ci = ci + 1
  }
  graphics::legend("left", legend = ids , col = colors[1:length(ids)], pch = 16, cex = 0.55)
  title(title)

  return(ci-1)

}
