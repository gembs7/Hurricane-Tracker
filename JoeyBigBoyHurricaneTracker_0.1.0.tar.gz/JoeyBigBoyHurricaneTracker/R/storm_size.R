#' Given the row number of the hurdat dataset, returns a plot of the size and
#' position of the storm listed in the row of the dataset. Graphs the
#' 34 knot wind (yellow), 50 knot wind (orange), 64 knot wind (red), Map will
#' be zoomed in to 80 degrees longitude and latitude of strom epicenter
#'
#' @param row row of hurricane dataset being plotted
#' @return a graph of the size and position of the storm at the given time
#' @export
storm_size = function(row) {

  longitude = as.numeric(row$Longitude)
  latitude = as.numeric(row$Latitude)




  calc_new_coords <- function(lat1, lon1, dist_km, tc_rad) {
    dist_km <- dist_km *1.82
    lat1_rad <- lat1 * pi/180
    lon1_rad <- lon1 * pi/180
    dist_rad <- dist_km / 6371.01
    lat2_rad <- asin(sin(lat1_rad) * cos(dist_rad) +
                       cos(lat1_rad) * sin(dist_rad) * cos(tc_rad))
    lon2_rad <- lon1_rad + atan2(sin(tc_rad) * sin(dist_rad) * cos(lat1_rad),
                                 cos(dist_rad) - sin(lat1_rad) * sin(lat2_rad))

    lat2 <- lat2_rad * 180/pi
    lon2 <- lon2_rad * 180/pi

    return(list(latitude = lat2, longitude = lon2))
  }


 points34 = c()
 NE34 = as.numeric(row[,"34Wind_Radii_NE"])
 SE34 = as.numeric(row[,"34Wind_Radii_SE"])
 NW34 = as.numeric(row[,"34Wind_Radii_NW"])
 SW34 = as.numeric(row[,"34Wind_Radii_SW"])
 for (rad in seq(from = 0, to = 2*pi, by = pi/12)){
   if (rad <= pi/4){
     distn = NE34 * ((pi/4) + rad)/ (pi/2) + SE34 * (1-((pi/4) + rad)/ (pi/2))
   } else if (rad <= 3*pi/4){
     distn = NW34 * (rad - (pi/4))/ (pi/2) + NE34 * (1-(rad - (pi/4))/ (pi/2))
   } else if (rad <= 5*pi/4){
     distn = SW34 * (rad - (3*pi/4))/ (pi/2) + NW34 * (1-(rad - (3*pi/4))/ (pi/2))
   } else if (rad <= 7*pi/4){
     distn = SE34 * (rad - (5*pi/4))/ (pi/2) + SW34 * (1-(rad - (5*pi/4))/ (pi/2))
   } else {
     distn = NE34 * (rad - (7*pi/4))/ (pi/2) + SE34 * (1-(rad - (7*pi/4))/ (pi/2))
   }

   newpt = calc_new_coords(latitude,longitude, distn, rad)
   points34 = append(points34, newpt)
 }


 points50 = c()
 NE50 = as.numeric(row[,"50Wind_Radii_NE"])
 SE50 = as.numeric(row[,"50Wind_Radii_SE"])
 NW50 = as.numeric(row[,"50Wind_Radii_NW"])
 SW50 = as.numeric(row[,"50Wind_Radii_SW"])
 for (rad in seq(from = 0, to = 2*pi, by = pi/12)){
   if (rad <= pi/4){
     distn = NE50 * ((pi/4) + rad)/ (pi/2) + SE50 * (1-((pi/4) + rad)/ (pi/2))
   } else if (rad <= 3*pi/4){
     distn = NW50 * (rad - (pi/4))/ (pi/2) + NE50 * (1-(rad - (pi/4))/ (pi/2))
   } else if (rad <= 5*pi/4){
     distn = SW50 * (rad - (3*pi/4))/ (pi/2) + NW50 * (1-(rad - (3*pi/4))/ (pi/2))
   } else if (rad <= 7*pi/4){
     distn = SE50 * (rad - (5*pi/4))/ (pi/2) + SW50 * (1-(rad - (5*pi/4))/ (pi/2))
   } else {
     distn = NE50 * (rad - (7*pi/4))/ (pi/2) + SE50 * (1-(rad - (7*pi/4))/ (pi/2))
   }

   newpt = calc_new_coords(latitude,longitude, distn, rad)
   points50 = append(points50, newpt)
 }


 points64 = c()
 NE64 = as.numeric(row[,"64Wind_Radii_NE"])
 SE64 = as.numeric(row[,"64Wind_Radii_SE"])
 NW64 = as.numeric(row[,"64Wind_Radii_NW"])
 SW64 = as.numeric(row[,"64Wind_Radii_SW"])
 for (rad in seq(from = 0, to = 2*pi, by = pi/12)){
   if (rad <= pi/4){
     distn = NE64 * ((pi/4) + rad)/ (pi/2) + SE64 * (1-((pi/4) + rad)/ (pi/2))
   } else if (rad <= 3*pi/4){
     distn = NW64 * (rad - (pi/4))/ (pi/2) + NE64 * (1-(rad - (pi/4))/ (pi/2))
   } else if (rad <= 5*pi/4){
     distn = SW64 * (rad - (3*pi/4))/ (pi/2) + NW64 * (1-(rad - (3*pi/4))/ (pi/2))
   } else if (rad <= 7*pi/4){
     distn = SE64 * (rad - (5*pi/4))/ (pi/2) + SW64 * (1-(rad - (5*pi/4))/ (pi/2))
   } else {
     distn = NE64 * (rad - (7*pi/4))/ (pi/2) + SE64 * (1-(rad - (7*pi/4))/ (pi/2))
   }

   newpt = calc_new_coords(latitude,longitude, distn, rad)
   points64 = append(points64, newpt)
 }



  if (is.na(NE34) || is.na(SE34) || is.na(SW34) || is.na(NW34) || is.na(NE50) || is.na(SE50) || is.na(SW50) || is.na(NW50) || is.na(NE64) || is.na(SE64) || is.na(SW64) || is.na(NW64)){
    stop("ERROR: Hurricane Row is missing intensity values")
  }

  if ((NE34) == 0 || (SE34) == 0 || (SW34) == 0 || (NW34) == 0 || (NE50) == 0 || (SE50) == 0 || (SW50) == 0 || (NW50) == 0 || (NE64) == 0 || (SE64) == 0 || (SW64) == 0 || (NW64) == 0){
    warning("WARNING: Hurricane Row has zero-value intensity values")
  }
  #dev.new(width=15, height=10)
  maps::map("world", fill = TRUE, col = "light gray", bg = "white", xlim = c(as.numeric(longitude)-20, as.numeric(longitude)+20), ylim = c(as.numeric(latitude)-20, as.numeric(latitude)+20))
  maps::map("state", fill = FALSE, add = TRUE, col = "black", lwd = 0.3)

  graphics::polygon(x = c(points34[seq(from = 2, to = length(points34), by = 2)]), y = c(points34[seq(from = 1, to = length(points34), by = 2)]), col = "yellow")
  graphics::polygon(x = c(points50[seq(from = 2, to = length(points50), by = 2)]), y = c(points50[seq(from = 1, to = length(points50), by = 2)]), col = "orange")
  graphics::polygon(x = c(points64[seq(from = 2, to = length(points64), by = 2)]), y = c(points64[seq(from = 1, to = length(points64), by = 2)]), col = "red")

  graphics::legend("right", legend = c("34 knot", "50 knot", "64 knot") , col = c("yellow", "orange", "red"), pch = 16, cex = 0.8)
  graphics::title(row[,1])
  return(TRUE)
}
