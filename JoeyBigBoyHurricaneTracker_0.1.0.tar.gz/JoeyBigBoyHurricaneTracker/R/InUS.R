#' takes in a storm ID and outputs "yes" if the storm made landfall in the
#' continental United States based on the longitude and latitude values of the
#' the storm path in Hurdat.
#' @param storm ID in AA111111 format.
#' @return a character vector containing either yes or no.
#' @examples
#' #determine whether Hurricane Bret made landfall in the continental US.
#' Bretinus<- InUS("AL022017")
#' print(Bretinus)
#' @export
InUS <- function(storm) {
  usmap <- maps::map("state", plot = FALSE, fill = TRUE)
  usmapsp <- maptools::map2SpatialPolygons(usmap, IDs = usmap$names)
  stormrows <- which(hurdata$ID == storm)
  storms <- hurdata[stormrows,]
  storms$Latitude <- as.numeric(storms$Latitude)
  storms$Longitude <- as.numeric(storms$Longitude)
  coords <- cbind(storms$Longitude, storms$Latitude)
  sppoints <- sp::SpatialPoints(coords)
  if (any(rgeos::gIntersects(sppoints, usmapsp, byid = TRUE))) {
    return("Yes")
  } else {
    return("No")
  }
}
