#' Interpolate the longitude and latitude points of a storm to thirty minute increments given a storm ID.
#' @param storm ID in AA###### format.
#' @return a dataframe with the first column containing the interpolated values of the latitude of the storm path in thirty minute increments
#' and a second column containing the interpolated values of the longitude of the storm path in thirty minute increments.
#' @examples
#' #Get interpolated path of Hurricane Katrina.
#' interKatrina<- Interpolate("AL122005")
#' print(interKatrina)
#' @export
Interpolate <- function(storm) {
  stormrows <- which(hurdata$ID == storm)
  storms <- hurdata[stormrows,]
  minutes <- c()
  starttime <- as.numeric(storms[1,4])
  for (i in 1:nrow(storms)) {
    minute <- (as.numeric(storms[i,3]) - as.numeric(storms[1,3])) * 24 * 60 + (as.numeric(storms[i,4]) - starttime) / 100 * 60
    minutes <- c(minutes, minute)
  }
  storms$Minutes <- minutes
  storms <- storms[order(minutes),]
  interpolatedlat <- c()
  interpolatedlon <- c()
  for (i in 1:(nrow(storms) - 1)) {
    latinter <- numeric()
    loninter <- numeric()
    for (j in 0:29) {
      fraction <- j / 30
      latinterj <- (1 - fraction) * as.numeric(storms[i,7]) + fraction * as.numeric(storms[i+1,7])
      loninterj <- (1 - fraction) * as.numeric(storms[i,8]) + fraction * as.numeric(storms[i+1,8])
      latinter <- c(latinter, latinterj)
      loninter <- c(loninter, loninterj)
    }
    interpolatedlat <- c(interpolatedlat, latinter)
    interpolatedlon <- c(interpolatedlon, loninter)
  }
  interpolatedlat <- c(interpolatedlat, as.numeric(storms[nrow(storms),7]))
  interpolatedlon <- c(interpolatedlon, as.numeric(storms[nrow(storms),8]))
  interpolateddf <- data.frame(Latitude = interpolatedlat, Longitude = interpolatedlon)
  return(interpolateddf)
}


