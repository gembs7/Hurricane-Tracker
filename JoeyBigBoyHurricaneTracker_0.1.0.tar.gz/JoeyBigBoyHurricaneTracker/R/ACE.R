#' Given a hurricane ID, return its Accumulated Cyclone Energy
#'
#' @param id A storm ID from the hurricane dataset
#' @return a list containing 2 values
#' \itemize{
#'     \item \code{ACE} Raw ACE value
#'     \item \code{ACE_reduced} ACE/10,000 common representation
#' }
#' @export
ACE = function (id) {
  dat = hurdata[grep(id, hurdata$ID),]
  dat$Time = as.numeric(dat$Time)
  dat = dat[((dat$Time == 0000) | (dat$Time == 0600) | (dat$Time == 1200) | (dat$Time == 1800)), "Max_Sus_Wind"]
  return (list("ACE" = sum(dat^2), "ACE_reduced" = sum(dat^2)/10000))
}
