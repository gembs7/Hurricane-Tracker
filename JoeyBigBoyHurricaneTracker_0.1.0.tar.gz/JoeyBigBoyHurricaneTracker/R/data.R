#' Hurricane Data for Atlantic tropical cyclones
#'
#' A dataset with the coordinates and information on Atlantic tropical cyclones
#'
#' @format a dataframe with 23 columns and 53972 rows
#' \describe{
#'      \item{Name}{Storm Name}
#'      \item{ID}{Storm ID}
#'      \item{Date}{Storm Date}
#'      \item{Time}{Storm Time}
#'      \item{Record_ID}{Record Identifier (C,G,I,L,P,R,S,T,W)}
#'      \item{System_Status}{Status of system based on wind/pressure. See: https://www.aoml.noaa.gov/hrd/hurdat/hurdat2-format.pdf}
#'      \item{Latitude}{Epicenter Latitude}
#'      \item{Longitude}{Epicenter Longitude}
#'      \item{Max_Sus_Wind}{Maximum Sustained Wind in knots}
#'      \item{Min_Pressure}{Minimum Pressure in millibars}
#'      \item{34Wind_Radii_NE}{34 kt wind radii maximum extent in northeastern quadrant (in nautical miles)}
#'      \item{34Wind_Radii_SE}{34 kt wind radii maximum extent in southeastern quadrant (in nautical miles)}
#'      \item{34Wind_Radii_SW}{34 kt wind radii maximum extent in southwestern quadrant (in nautical miles)}
#'      \item{34Wind_Radii_NW}{34 kt wind radii maximum extent in northwestern quadrant (in nautical miles)}
#'      \item{50Wind_Radii_NE}{50 kt wind radii maximum extent in northeastern quadrant (in nautical miles)}
#'      \item{50Wind_Radii_SE}{50 kt wind radii maximum extent in southeastern quadrant (in nautical miles)}
#'      \item{50Wind_Radii_SW}{50 kt wind radii maximum extent in southwestern quadrant (in nautical miles)}
#'      \item{50Wind_Radii_NW}{50 kt wind radii maximum extent in northwestern quadrant (in nautical miles)}
#'      \item{64Wind_Radii_NE}{64 kt wind radii maximum extent in northeastern quadrant (in nautical miles)}
#'      \item{64Wind_Radii_SE}{64 kt wind radii maximum extent in southeastern quadrant (in nautical miles)}
#'      \item{64Wind_Radii_SW}{64 kt wind radii maximum extent in southwestern quadrant (in nautical miles)}
#'      \item{64Wind_Radii_NW}{64 kt wind radii maximum extent in northwestern quadrant (in nautical miles)}
#'      \item{Max_Radius}{Maximum radius of storm (in nautical miles)}
#' }
"hurdata"
